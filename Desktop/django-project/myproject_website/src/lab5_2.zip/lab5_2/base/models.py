import django.utils.timezone
from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.models import User
from datetime import datetime, date
from django.utils.timezone import make_aware, is_aware

class Task(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    complete = models.BooleanField(default=False, null=False)
    created = models.DateField(auto_now_add=True)
    deadline = models.DateTimeField("Set the deadline in the following format: 'month/day/year hours:minutes:seconds'", auto_now_add=False, auto_now=False, blank=True, null=True)

    def save(self, *args, **kwargs):
        from dateutil import parser
        deadline = parser.parse(str(self.deadline))
        now = datetime.now()

        if not is_aware(deadline):
            deadline = make_aware(deadline)
        if not is_aware(now):
            now = make_aware(now)

        if deadline < now:
            raise ValidationError("The date cannot be in the past!")
        super(Task, self).save(*args, **kwargs)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-created']

